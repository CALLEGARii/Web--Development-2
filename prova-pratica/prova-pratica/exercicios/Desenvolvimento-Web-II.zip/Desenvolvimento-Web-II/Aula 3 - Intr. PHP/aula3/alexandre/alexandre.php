<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pagina daora</title>
</head>

<body>
    <?php
    echo "<h1>Alexandre Augusto dos Santos Feltrin</h1>";
    echo "<h2>Aula Web 3</h2>";
    echo "<hr>";
    echo '<a href="../hello.php">Hello World</a>';
    ?>
</body>

</html>